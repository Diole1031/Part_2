# Recipe App

## Description
The Recipe App is a command-line application written in C# that empowers users to manage their recipes effectively. Whether you're a seasoned chef or a cooking enthusiast, this app provides a convenient way to organize, store, and access your favorite recipes.

## Features
- **Enter Recipe:** Easily input the details of your recipe, including ingredients and steps, using a simple and intuitive interface.
- **Display Recipes:** View the full details of your recipes, including ingredients, quantities, and steps, presented in a neat and organized format.
- **Scale Quantities:** Adjust the quantities of ingredients in your recipe by scaling them up or down according to your preferences.
- **Reset Quantities:** Quickly revert the quantities of ingredients back to their original values with the click of a button.
- **Clear Data:** Start fresh by clearing all entered recipe data, allowing you to enter a new recipe with ease.

## How to Run
To run the Recipe App, follow the instructions below:

1. **Clone the Repository:** Clone this repository to your local machine.
2. **Navigate to the Project Directory:** Open a terminal or command prompt and navigate to the directory where you cloned the repository.
3. **Compile the Program:** Use the `dotnet build` command to compile the program.
4. **Run the Program:** Execute the `dotnet run` command to run the program.
5. **Interact with the Application:** Follow the on-screen instructions to interact with the application and manage your recipes.
6. **Exit the Program:** To exit the program, select the appropriate option from the menu.

## Requirements
- [.NET SDK](https://dotnet.microsoft.com/download): Ensure that you have the .NET SDK installed on your system to compile and run the program.

## Contributing
Contributions to the Recipe App are welcome! If you encounter any issues or have suggestions for improvements, please feel free to open an issue or create a pull request on GitHub.

## About
This project is part of a portfolio of evidence for Programming 2a. It aims to demonstrate proficiency in object-oriented programming, C# programming language, and software design principles.

