﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{
    // Class to represent an ingredient
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Grams { get; set; } // Added property for grams
        public string FoodGroup { get; set; }
    }

    // Class to represent a recipe
    class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<string> Steps { get; set; } = new List<string>();

        // Method to calculate total grams of the recipe
        public int CalculateTotalGrams()
        {
            int totalGrams = 0;
            foreach (var ingredient in Ingredients)
            {
                totalGrams += ingredient.Grams;
            }
            return totalGrams;
        }
    }

    class Program
    {
        static List<Recipe> recipes = new List<Recipe>();

        static void Main(string[] args)
        {
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Enter Recipe");
                Console.WriteLine("2. Display Recipes");
                Console.WriteLine("3. Exit");
                Console.WriteLine("Enter your choice:");

                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid choice. Please enter a number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        EnterRecipe();
                        break;
                    case 2:
                        DisplayRecipes();
                        break;
                    case 3:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void EnterRecipe()
        {
            Recipe recipe = new Recipe();

            Console.WriteLine("Enter recipe name:");
            recipe.Name = Console.ReadLine();

            Console.WriteLine("Enter the number of ingredients:");
            int numIngredients = int.Parse(Console.ReadLine());
            for (int i = 0; i < numIngredients; i++)
            {
                Ingredient ingredient = new Ingredient();

                Console.WriteLine($"Ingredient {i + 1} name:");
                ingredient.Name = Console.ReadLine();

                Console.WriteLine($"Ingredient {i + 1} quantity:");
                ingredient.Quantity = double.Parse(Console.ReadLine());

                Console.WriteLine($"Ingredient {i + 1} unit:");
                ingredient.Unit = Console.ReadLine();

                Console.WriteLine($"Ingredient {i + 1} grams:"); // Prompt for grams
                ingredient.Grams = int.Parse(Console.ReadLine());

                Console.WriteLine($"Ingredient {i + 1} food group:");
                ingredient.FoodGroup = Console.ReadLine();

                recipe.Ingredients.Add(ingredient);
            }

            Console.WriteLine("Enter the number of steps:");
            int numSteps = int.Parse(Console.ReadLine());
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Step {i + 1}:");
                recipe.Steps.Add(Console.ReadLine());
            }

            recipes.Add(recipe);
            Console.WriteLine("Recipe added successfully.");
        }

        static void DisplayRecipes()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("\nRecipes:");
            foreach (var recipe in recipes)
            {
                Console.WriteLine($"- {recipe.Name}");
            }

            Console.WriteLine("Enter the name of the recipe to display:");
            string recipeName = Console.ReadLine();

            Recipe selectedRecipe = recipes.Find(r => r.Name == recipeName);
            if (selectedRecipe == null)
            {
                Console.WriteLine("Recipe not found.");
                return;
            }

            Console.WriteLine($"\nRecipe: {selectedRecipe.Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in selectedRecipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit} ({ingredient.Grams} grams)"); // Display grams
            }
            Console.WriteLine("\nSteps:");
            foreach (var step in selectedRecipe.Steps)
            {
                Console.WriteLine(step);
            }

            int totalGrams = selectedRecipe.CalculateTotalGrams();
            Console.WriteLine($"\nTotal Grams: {totalGrams}");
        }
    }
}


